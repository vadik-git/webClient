﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            WebClient client = new WebClient();
            // string ad = "https://www.google.com/search?q=%D0%BA%D0%B0%D1%80%D1%82%D0%B8%D0%BD%D0%BA%D0%B8&sxsrf=ALeKk00DXXll9-fy3cCi5W8YSo7alG6Qsw:1616354104221&tbm=isch&source=iu&ictx=1&fir=gFnA3Q2mdkY6ZM%252Ca_pWxrf95S5u7M%252C_&vet=1&usg=AI4_-kS-kb2Gx3w9GwzvRGtqAGUrMP2kRA&sa=X&ved=2ahUKEwjIgdqhjMLvAhVNs4sKHc53D64Q9QF6BAgDEAE#imgrc=gFnA3Q2mdkY6ZM";
            // string ad = "http://212.183.159.230/20MB.zip";
            string ad ="https://bigpicture.ru/wp-content/uploads/2015/11/nophotoshop29-800x532.jpg";
            string target = Path.Combine("C:/Users/Vadim/Desktop/BadFiles","vadimko.jpg");
            Console.WriteLine("LOADED");
            DownloadFile(ad,target);
            Console.ReadKey();

        }
        private static void DownloadFile(string address,string target)
        {
            WebClient client = new WebClient();

           

            string fileName = Path.GetFileName(address);

             client.DownloadFileTaskAsync(
                new Uri(address),
               target);

            Console.WriteLine($"{fileName} - File loaded!");
        }
    }
}
