﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DownloadFilePract
{
    public class FileInfo : INotifyPropertyChanged
    {
        public string adressFile { get; set; }
        public string NameFile { get; set; } = "Vadim"; 
        public string pathDownloadTo { get; set; }

        string proc;
        public string Procent { get { return proc; }
            set {

                proc = value;
                OnPropertyChanged();
            }
        }

        public override string ToString()
        {
            return $"{NameFile} - {Procent} ";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }




    }
}
