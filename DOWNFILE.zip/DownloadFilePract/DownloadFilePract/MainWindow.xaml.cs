﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Collections.ObjectModel;
using System.Threading;

namespace DownloadFilePract
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public ObservableCollection<FileInfo> myList = new ObservableCollection<FileInfo>();
       
       
        public MainWindow()
        {
            InitializeComponent();
            // this.DataContext = new FileInfo();
           downList.ItemsSource = myList;

           ListBox.DisplayMemberPath = "Title";
           ListBox.SelectedValuePath = "Path";
        }

        string data;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ListBox.Items.Clear();
                for (int i = 0; i < 5; i++)
                {
                    FileInfo info = new FileInfo() {
                        NameFile = $"{i + 1}-{tbNameFile.Text}",
                        adressFile = TbLink.Text,
                        pathDownloadTo = tbFoldetPath.Text,
                        //Procent = " "
                    
                };
                      myList.Add(info);

               
                 ThreadPool.QueueUserWorkItem(DownloadFile, info);

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        public void DownloadFile(object obj)
        {
            FileInfo file = obj as FileInfo;
            WebClient client = new WebClient();
            string target = System.IO.Path.Combine(file.pathDownloadTo, file.NameFile);

            client.DownloadProgressChanged += Client_DownloadProgressChanged;

           // file.Procent = data;
            string fileName = System.IO.Path.GetFileName(file.adressFile);

            client.DownloadFile(new Uri(file.adressFile), target);


        }

        private void Client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {

             data = $"{e.BytesReceived / 1024 / 1024}MB of {e.TotalBytesToReceive / 1024 / 1024}MB {e.ProgressPercentage}%";

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            try
            {

                string[] files = Directory.GetFiles("C:/Users/Vadim/Desktop/BadFiles");
                ListBox.Items.Clear();
                foreach (var i in files)
                {
                    var file = new MyFile { Title = System.IO.Path.GetFileName(i), Path = System.IO.Path.GetFullPath(i) };

                    ListBox.Items.Add(file);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                var item = ListBox.SelectedItems.Cast<MyFile>();
                var path = string.Join(Environment.NewLine, item.Select(x => x.Path));
                MessageBox.Show($"{path}");
                File.Delete(path);
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    }
}
